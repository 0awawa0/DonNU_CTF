import os
import random
from PIL import Image
from figures import *


class Generator:

	def __init__(self, flag):
		self.flag = flag

	def generate(self, timestamp, availableFigures = []):
		size = (1920, 1080)
		backgroundColor = (random.randint(0, 75), random.randint(0, 75), random.randint(0, 75))
		img = Image.new(size = size, mode = "RGB", color = backgroundColor)

		if len(availableFigures) == 0:
			fileName = os.urandom(8).hex()
			img.save(f"{fileName}.png")
			return fileName

		colors = []
		figures = []
		for i in self.flag:
			k = random.randint(50, 100) * 0.03
			figure = random.choice(availableFigures)
			if figure != ArchimedeanSpiral or figure != FermatSpiral:
				figures.append(figure(k, angle = random.randint(0, 360)))
			else:
				figures.append(random.choice(availableFigures)(k))
			red = random.randint(1, 175) % 175
			green = i
			blue = random.randint(1, 175) % 175
			colors.append((red, green, blue))

		centers = []
		random.seed(timestamp)
		for i in self.flag:
			x = random.randint(50, size[0] - 50)
			y = random.randint(50, size[1] - 50)
			while (x, y) in centers:
				x = random.randint(50, size[0] - 50)
				y = random.randint(50, size[1] - 50)
			centers.append((x, y))


		for i in range(len(self.flag)):
			s = figures[i]
			s.draw(
				img,
				center = Dot(centers[i][0], centers[i][1]), 
				color = Color(colors[i][0], colors[i][1], colors[i][2]), 
				ignore = centers
			)

		fileName = os.urandom(8).hex()
		img.save(f"{fileName}.png")
		return fileName
