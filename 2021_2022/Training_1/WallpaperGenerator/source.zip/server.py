import os
import time
import random
import logging
from PIL import Image
from Generator import Generator
from Validator import Validator
from figures import *
from http.server import BaseHTTPRequestHandler, HTTPServer


class TaskServer(BaseHTTPRequestHandler):

    def _set_text_response(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()

    def _set_img_response(self):
        self.send_response(200)
        self.send_header('Content-type', 'image/x-png')
        self.end_headers()        


    def parse_args(self, path):
        s = path.split("?")
        if len(s) < 2: 
            return (s[0], {})

        args = s[1].split("&")
        args = {i.split("=")[0]: i.split("=")[1] for i in args}
        return (s[0], args)

    def generateImage(self, availableFigures = []):
        flag = open('flag', 'rb').read().strip()
        generator = Generator(flag)
        validator = Validator(flag) # Checks if fag can be extracted from generated image

        timestamp = round(time.time())
        fileName = generator.generate(timestamp, availableFigures)
        while not validator.validate(timestamp, fileName):
            os.remove(f"{fileName}.png")
            timestamp = round(time.time())
            fileName = generator.generate(timestamp)

        data = open(f"{fileName}.png", 'rb').read()
        os.remove(f"{fileName}.png")
        return data

    def do_GET(self):
        path, args = self.parse_args(self.path)
        if path == "/get_image":
            availableFigures = []
            if "archimedean" in args and args["archimedean"] == 'on': availableFigures.append(ArchimedeanSpiral)
            if "fermat" in args and args["fermat"] == 'on': availableFigures.append(FermatSpiral)
            if "astroid" in args and args["astroid"] == 'on': availableFigures.append(Astroid)
            if "three_leaves_rose" in args and args["three_leaves_rose"] == "on": availableFigures.append(ThreeLeavesRose)
            if "four_leaves_rose" in args and args["four_leaves_rose"] == "on": availableFigures.append(FourLeavesRose)
            if "cardioid" in args and args["cardioid"] == "on": availableFigures.append(Cardioid)

            self._set_img_response()
            self.wfile.write(self.generateImage(availableFigures))
            
        elif path == "/background.png":
            self._set_img_response()
            self.wfile.write(open("background.png", 'rb').read())
        elif path == "/archimedean_spiral.png":
            self._set_img_response()
            self.wfile.write(open("archimedean_spiral.png", 'rb').read())
        elif path == "/fermat_spiral.png":
            self._set_img_response()
            self.wfile.write(open("fermat_spiral.png", 'rb').read())
        elif path == "/astroid.png":
            self._set_img_response()
            self.wfile.write(open("astroid.png", 'rb').read())
        elif path == "/three_leaves_rose.png":
            self._set_img_response()
            self.wfile.write(open("three_leaves_rose.png", 'rb').read())
        elif path == "/four_leaves_rose.png":
            self._set_img_response()
            self.wfile.write(open("four_leaves_rose.png", 'rb').read())
        elif path == "/cardioid.png":
            self._set_img_response()
            self.wfile.write(open("cardioid.png", 'rb').read())
        else:
            self._set_text_response()
            self.wfile.write(open("page.html", 'rb').read())


def run(server_class=HTTPServer, handler_class=TaskServer, port=43585):
    logging.basicConfig(level=logging.INFO)
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    logging.info('Starting server\n')
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()
    logging.info('Server stopped\n')


if __name__ == '__main__':
    from sys import argv

    if len(argv) == 2:
        run(port=int(argv[1]))
    else:
        run()