import os
import random
from PIL import Image


class Validator:

	def __init__(self, flag):
		self.flag = flag

	def validate(self, timestamp, fileName):
		img = Image.open(f'{fileName}.png')
		pixels = img.load()

		centers = []
		random.seed(timestamp)
		for _ in range(len(self.flag)):
			x = random.randint(50, img.width - 50)
			y = random.randint(50, img.height - 50)
			while (x, y) in centers:
				x = random.randint(50, img.width - 50)
				y = random.randint(50, img.height - 50)
			centers.append((x, y))

		flag = ""
		for i in range(len(self.flag)):
			p = pixels[centers[i][0], centers[i][1]]
			flag += chr(p[1])
	
		return flag.encode() == self.flag
