from math import pi as PI
from math import cos, sin, sqrt
from typing import Callable


class Dot:
	def __init__(self, x: float, y: float):
		self.x = x
		self.y = y
		self.tuple = (x, y)
		self.intTuple = (round(x), round(y))

	def shift(self, center, angle: float = 0):
		newX = center.x + (self.x * cos(angle) - self.y * sin(angle))
		newY = center.y + (self.x * sin(angle) + self.y * cos(angle))
		self.x = newX
		self.y = newY
		self.tuple = (newX, newY)
		self.intTuple = (round(newX), round(newY))

	def isWithinBoards(self, minPoint, maxPoint):
		return self.x >= minPoint.x and self.y >= minPoint.y and self.x <= maxPoint.x and self.y <= maxPoint.y


class Color:
	def __init__(self, red: int = 0, green: int = 0, blue: int = 0):
		self.red = red
		self.green = green
		self.blue = blue
		self.tuple = (red, green, blue)


class AbstractFigureDrawer:


	def __init__(self,
		startValue: float = 0, 
		step: float = 0.02, 
		angle:float  = 0, 
		maxPoints: int = 10000,
		getNext: Callable = lambda x: Dot(x, x)
	):

		self.angle = angle * PI / 180
		self.startValue = startValue
		self.step = step
		self.maxPoints = maxPoints
		self.getNext = getNext

	def draw(self, image, center: Dot = Dot(0, 0), color: Color = Color(), ignore: set = set()):

		f = self.startValue
		pointsCount = 1

		nextPoint = self.getNext(f)
		nextPoint.shift(center, self.angle)

		image.putpixel(center.intTuple, color.tuple)
		boards = (Dot(0, 0), Dot(image.width - 1, image.height - 1))
		while nextPoint.isWithinBoards(boards[0], boards[1]) and pointsCount < self.maxPoints:
			if nextPoint.intTuple not in ignore: image.putpixel(nextPoint.intTuple, color.tuple)
			f += self.step
			nextPoint = self.getNext(f)
			nextPoint.shift(center, self.angle)
			pointsCount += 1
		

class ArchimedeanSpiral(AbstractFigureDrawer):

	def __init__(self, k = 1, startValue = 0, step = 0.02, angle = 0, maxPoints = 20000):
		self.k = k
		super().__init__(
			startValue, 
			step, 
			angle, 
			maxPoints, 
			lambda x: Dot(self.k * x * cos(x), self.k * x * sin(x))
		)


class FermatSpiral(AbstractFigureDrawer):

	def calcNext(self, x):
		return Dot(self.k * sqrt(x) * cos(x), self.k * sqrt(x) * sin(x))

	def __init__(self, k = 1, startValue = 0, step = 0.1, angle = 0, maxPoints = 50000):
		self.k = k * 2.5
		self.counter = 0
		super().__init__(
			startValue,
			step, 
			angle, 
			maxPoints, 
			self.calcNext
		)


class Astroid(AbstractFigureDrawer):
	def __init__(self, k = 1, startValue = 0, step = 1, angle = 0, maxPoints = 5000):
		self.k = k * 70
		super().__init__(
			startValue,
			step,
			angle,
			maxPoints,
			lambda x: Dot(self.k * cos(x) ** 3, self.k * sin(x) ** 3)
		)


class ThreeLeavesRose(AbstractFigureDrawer):
	def __init__(self, k = 1, startValue = 0, step = 1, angle = 0, maxPoints = 5000):
		self.k = k * 50
		super().__init__(
			startValue,
			step,
			angle,
			maxPoints,
			lambda x: Dot(self.k * cos(3 * x) * cos(x), self.k * cos(3 * x) * sin(x))
		)



class FourLeavesRose(AbstractFigureDrawer):

	def __init__(self, k = 1, startValue = 0, step = 1, angle = 0, maxPoints = 5000):
		self.k = k * 50
		super().__init__(
			startValue,
			step,
			angle,
			maxPoints,
			lambda x: Dot(self.k * cos(2 * x) * cos(x), self.k * cos(2 * x) * sin(x))
		)


class Cardioid(AbstractFigureDrawer):

	def __init__(self, k = 1, startValue = 0, step = 1, angle = 0, maxPoints = 5000):
		self.k = k * 20
		super().__init__(
			startValue,
			step,
			angle,
			maxPoints,
			lambda x: Dot(2 * self.k * cos(x) - self.k * cos(2 * x), 2 * self.k * sin(x) - self.k * sin(2 * x))
		)
