import hashlib
from hashlib import md5
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad


p = 
g = 
A = 
B = 
key=common_secret


key = md5(key.to_bytes(128, 'big')).digest()
cipher = AES.new(key, AES.MODE_ECB)
encrypt = lambda m: cipher.encrypt(pad(m.encode(), AES.block_size))
d=encrypt(flag).hex()
print(' Here is your encrypted flag:',d)


  

