from PIL import Image


def textToBin(text): return "".join(f"{bin(i)[2:]:0>8}" for i in text)


def encodeFlag(img, flag):
	
	pixels = img.load()
	currentPosition = (0, 0)
	vertical = False
	channel = 0
	bitsArray = [int(i) for i in flag]
	mask = 0b11111110

	while (currentPosition[0] < img.width and currentPosition[1] < img.height):
		for bit in bitsArray:
			if (currentPosition[0] >= img.width or currentPosition[1] >= img.height): break

			r, g, b = pixels[currentPosition]

			if (channel == 0): r = (r & mask) | bit
			elif (channel == 1): g = (g & mask) | bit
			else: b = (b & mask) | bit

			pixels[currentPosition] = (r, g, b)

			if (vertical):
				currentPosition = (currentPosition[0] + 1, currentPosition[1] + 2)
			else:
				currentPosition = (currentPosition[0] + 2, currentPosition[1] + 1)

			vertical = not vertical
			channel = (channel + 1) % 3

	img.save("encoded.png")


if __name__ == "__main__":
	img = Image.open("img.png")
	flag = open("flag").read().strip().encode()
	flagBin = textToBin(flag)
	encodeFlag(img, flagBin)
