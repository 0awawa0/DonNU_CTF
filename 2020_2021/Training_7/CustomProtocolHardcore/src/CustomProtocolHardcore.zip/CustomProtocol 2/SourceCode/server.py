import socket
import random
import threading
import Protocol
from ezRSA.ezRSA import *


class Server:

	SERVER_ADDRESS = ('localhost', 43584)
	MAX_CONNECTIONS = 25
	PRIMES_LENGTH = 1024

	class ClientModel:

		def __init__(self, connection, address):
			self.connection = connection
			self.address = address
			self.nickname = ""
			self.primes = []
			self.e = 0
			self.cipher = None


	def __init__(self):
		self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.socket.bind(Server.SERVER_ADDRESS)
		self.cipher = None
		self.index = 0
		self.clients = []
		self.socket.listen(Server.MAX_CONNECTIONS)
		self.p = int(open("./encryptionParams/p.txt", 'r').read())
		self.q = int(open("./encryptionParams/q.txt", 'r').read())
		self.e_array = [int(i) for i in open("./encryptionParams/e_array.txt", 'r').readlines()]

	def handle_connection(self, client):

		while 1:

			rcv = client.connection.recv(Protocol.MAX_PACKET_LENGTH)
			if len(rcv) == 0:
				break
			rcv = Protocol.PacketInterface.parse_buffer(rcv)

			response = None

			if type(rcv) == Protocol.ConnectRequest:
				if not client.cipher:
					index = random.randint(0, len(self.e_array))
					client.index = index
					client.cipher = RSA.fromRawParams(self.e_array[index], [self.p, self.q])

				response = Protocol.ConnectResponse(client.index)

			if type(rcv) == Protocol.NicknameRequest:
				print(f"{rcv.nickname} joined the chatroom")
				result = "OK"
				for c in self.clients:
					if client.nickname == rcv.nickname:
						result = "ERROR"
						break
				if result == "OK":
					client.nickname = rcv.nickname

				response = Protocol.NicknameResponse(result)

			if type(rcv) == Protocol.MessageRequest:
				text = client.cipher.decrypt(rcv.message)
				self.broadcast(client.nickname, text)
				continue

			if type(rcv) == Protocol.Leave:
				client.connection.close()
				self.clients.remove(client)
				break

			if response:
				client.connection.send(response.get_buffer())
		client.connection.close()

	def broadcast(self, nickname, message):
		for client in self.clients:
			packet = Protocol.MessageRequest(nickname, client.cipher.encrypt(message))
			client.connection.send(packet.get_buffer())

	def run(self):
		
		print("Server is running... Press Ctrl-C to stop it.")

		while 1:
			connection, address = self.socket.accept()
			client = Server.ClientModel(connection, address)
			print(f"Client connected {address}")
			self.clients.append(client)
			thread = threading.Thread(target=self.handle_connection, args=(client, ))
			thread.start()

		self.socket.close()


if __name__ == "__main__":

	server = Server()
	server.run()