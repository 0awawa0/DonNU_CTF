import socket
import sys
import threading
import curses
import Protocol
import client_main_ui
from PyQt5 import QtWidgets
from ezRSA.ezRSA import *


class Client:

	SERVER_ADDRESS = ('localhost', 43584)

	def __init__(self, interface):
		self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.cipher = None
		self.nickname = ""
		self.interface = interface
		self.joined = False
		self.running = True
		self.p = int(open("./encryptionParams/p.txt", 'r').read())
		self.q = int(open("./encryptionParams/q.txt", 'r').read())
		self.m = int(open("./encryptionParams/modulus.txt", 'r').read())
		self.e_array = [int(i) for i in open("./encryptionParams/e_array.txt", 'r').readlines()]

	def onSend(self, message):

		if self.joined:
			if message == "<leave>":
				packet = Protocol.Leave()
				self.socket.send(packet.get_buffer())
				self.socket.close()
				QCoreApplication.instance().quit()
			else:
				packet = Protocol.MessageRequest(self.nickname, self.cipher.encrypt(int(message.encode().hex(), 16)))
				self.socket.send(packet.get_buffer())		
		else:
			print(f"Sending nick request: {message}")
			packet = Protocol.NicknameRequest(message)
			self.socket.send(packet.get_buffer())

			data = self.socket.recv(Protocol.MAX_PACKET_LENGTH)
			packet = Protocol.PacketInterface.parse_buffer(data)
			if type(packet) == Protocol.NicknameResponse:
				if packet.result == "OK":
					self.nickname = message
					self.interface.chatLog.append("You have joined chat")
					self.joined = True
				else:
					self.interface.chatLog.append("Nickname exists")

	def rcvThread(self):
		while self.running:
			data = self.socket.recv(Protocol.MAX_PACKET_LENGTH)
			if len(data) == 0: break
			packet = Protocol.PacketInterface.parse_buffer(data)
			if type(packet) == Protocol.MessageRequest:
				message = int_to_bytes(self.cipher.decrypt(packet.message)).decode()
				self.interface.chatLog.append(f"{packet.nickname}::{message}")
			
	
	def run(self):
		self.interface.chatLog.append("Connecting to the server...")
		self.socket.connect(Client.SERVER_ADDRESS)
		self.interface.chatLog.append("Connection established!")


		self.interface.chatLog.append("Requesting encryption params...")
		rsa_request_packet = Protocol.ConnectRequest()
		self.socket.send(rsa_request_packet.get_buffer())

		data = self.socket.recv(Protocol.MAX_PACKET_LENGTH)

		if len(data) == 0: return
		packet = Protocol.PacketInterface.parse_buffer(data)

		if type(packet) is Protocol.ConnectResponse:
			self.cipher = RSA.fromRawParams(self.e_array[packet.index], [self.p, self.q])
		else:
			self.interface.chatLog.append("Error occured. Code -1")
			return
		self.interface.chatLog.append("Encryption params received")

		self.interface.chatLog.append("Enter your nickname to join chat")

		rcv = threading.Thread(target=self.rcvThread)
		rcv.start()


class ClientApp(QtWidgets.QMainWindow, client_main_ui.Ui_MainWindow):

	def __init__(self):
		super().__init__()
		self.setupUi(self)
		self.client = Client(self)
		self.client.run()
		self.sendButton.clicked.connect(self.sendClicked)

	def sendClicked(self):
		self.client.onSend(str(self.messageInput.text()))
		self.messageInput.setText("")

	def closeEvent(self, event):
		self.client.running = False
		self.client.socket.close()
		event.accept()


if __name__ == "__main__":
	
	app = QtWidgets.QApplication(sys.argv)
	window = ClientApp()
	window.show()
	app.exec_()
