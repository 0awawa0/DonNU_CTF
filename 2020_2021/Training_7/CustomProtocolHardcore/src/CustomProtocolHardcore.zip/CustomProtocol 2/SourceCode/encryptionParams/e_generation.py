from ezRSA.ezRSA import *


print("Generating primes")
p = get_prime(2048)
q = get_prime(2048)
modulus = p * q

open("p.txt", 'w').write(str(p))
open("q.txt", 'w').write(str(q))
open("modulus.txt", 'w').write(str(modulus))

print("Calculating Euler's totient")
fn = eulers_totient(modulus, [p, q])

e_array = []

file = open("e_array.txt", 'w')

print("Collecting exponents")
for i in range(10000, 100000):
	if gcd(i, fn) == 1:
		accept = True
		for e in e_array:
			if gcd(i, e) != 1:
				accept = False
		if accept:
			e_array.append(i)

file.write("\n".join([str(i) for i in e_array]))
file.close()