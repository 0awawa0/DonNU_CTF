from ezRSA.ezRSA import *


p = int(open("p.txt", 'r').read())
q = int(open("q.txt", 'r').read())

text = b"donnuCTF{test_flag}"

e_array = [int(i) for i in open("e_array.txt", 'r').readlines()]

for e in e_array:
	cipher = RSA.fromRawParams(e, [p, q])
	check = int_to_bytes(cipher.decrypt(cipher.encrypt(bytes_to_int(text))))
	if check != text:
		print(e)
