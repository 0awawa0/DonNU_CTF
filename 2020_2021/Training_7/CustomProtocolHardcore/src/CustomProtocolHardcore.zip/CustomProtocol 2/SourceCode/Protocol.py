

MAX_PACKET_LENGTH = 4096


class PacketInterface:

	MAGIC_NUMBER_CONNECT_REQUEST = "12345678"

	# CONNECT REQUEST FORMAT:
	# |MAGIC_NUMBER <4 bytes>|
	#

	MAGIC_NUMBER_CONNECT_RESPONSE = "87654321"
	
	# CONNECT RESPONSE FORMAT:
	# |MAGIC_NUMBER <4 bytes>|INDEX|

	MAGIC_NUMBER_NICKNAME_REQUEST = "cafebabe"

	# NICKNAME REQUEST FORMAT:
	# 	|MAGIC_NUMBER <4 bytes>|NICKNAME|
	#

	MAGIC_NUMBER_NICKNAME_RESPONSE = "babecafe"

	# NICKNAME RESPONSE FORMAT:
	#	|MAGIC_NUMBER <4 bytes>|RESPONSE: {OK, USER_EXISTS}|
	#

	MAGIC_NUMBER_MESSAGE_REQUEST = "deadbeef"

	# MESSAGE REQUEST FORMAT:
	# 	|MAGIC_NUMBER <4 bytes>|NICKNAME::MESSAGE|
	#

	MAGIC_NUMBER_LEAVE = "beefdead"

	# LEAVE FORMAT:
	# 	|MAGIC_NUMBER <4 bytes>|
	#

	def __init__(self, magic_number, fields):

		self.magic_number = magic_number
		self.fields = fields

	def get_buffer(self):
		pass

	@staticmethod
	def parse_buffer(data):
		magic_number = data[:4].hex()

		if magic_number == PacketInterface.MAGIC_NUMBER_CONNECT_REQUEST:
			return ConnectRequest()

		elif magic_number == PacketInterface.MAGIC_NUMBER_CONNECT_RESPONSE:
			index = int(data[4:].hex(), 16)
			return ConnectResponse(index)

		elif magic_number == PacketInterface.MAGIC_NUMBER_NICKNAME_REQUEST:
			nickname = data[4:].decode()
			return NicknameRequest(nickname)

		elif magic_number == PacketInterface.MAGIC_NUMBER_NICKNAME_RESPONSE:
			result = data[4:].decode()
			return NicknameResponse(result)

		elif magic_number == PacketInterface.MAGIC_NUMBER_MESSAGE_REQUEST:
			nickname, message = data[4:].decode().split("::")
			message = int(message, 16)
			return MessageRequest(nickname, message)

		elif magic_number == PacketInterface.MAGIC_NUMBER_LEAVE:
			return Leave()

		else:
			print(f"Unknown magic number: {magic_number}")


class ConnectRequest(PacketInterface):

	def __init__(self):
		super().__init__(PacketInterface.MAGIC_NUMBER_CONNECT_REQUEST, {})

	def get_buffer(self):
		return bytes.fromhex(self.magic_number)


class ConnectResponse(PacketInterface):

	def __init__(self, index):
		self.index = index
		super().__init__(PacketInterface.MAGIC_NUMBER_CONNECT_RESPONSE, {"INDEX": self.index})

	def get_buffer(self):
		return bytes.fromhex(self.magic_number) \
			+ self.index.to_bytes((self.index.bit_length() + 7) // 8, "big")


class NicknameRequest(PacketInterface):

	def __init__(self, nickname):
		self.nickname = nickname
		super().__init__(PacketInterface.MAGIC_NUMBER_NICKNAME_REQUEST, {"NICKNAME": self.nickname})

	def get_buffer(self):
		return bytes.fromhex(self.magic_number) + self.nickname.encode()

class NicknameResponse(PacketInterface):

	def __init__(self, result):
		self.result = result
		super().__init__(PacketInterface.MAGIC_NUMBER_NICKNAME_RESPONSE, {"RESULT": self.result})

	def get_buffer(self):
		return bytes.fromhex(self.magic_number) + self.result.encode()


class MessageRequest(PacketInterface):

	def __init__(self, nickname, message):
		self.nickname = nickname
		self.message = message
		super().__init__(PacketInterface.MAGIC_NUMBER_MESSAGE_REQUEST, {"MESSAGE": self.message})

	def get_buffer(self):
		return bytes.fromhex(self.magic_number) + self.nickname.encode() + "::".encode() + hex(self.message)[2:].encode()


class Leave(PacketInterface):

	def __init__(self):
		super().__init__(PacketInterface.MAGIC_NUMBER_LEAVE, {})

	def get_buffer(self):
		return bytes.fromhex(self.magic_number)
